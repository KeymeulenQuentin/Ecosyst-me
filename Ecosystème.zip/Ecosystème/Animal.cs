﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    static class Globals
    {
        public static int Health_point2 = 5;
    }
    public class Animal : Specie
    {
        public int Health_point;
        public int Energy_point;
        public string gender;
        public int trip;
        public int vision_zone;
        public int contact_zone;
        public int gestation_period;
        public string alimentation;

        public Animal(int Health_point, int Energy_point, int OX, int OY, string gender, int trip, int vision_zone, int contact_zone, int gestation_period, string alimentation) : base(OX, OY)
        {
            this.Health_point = Health_point;
            this.Energy_point = Energy_point;
            this.gender = gender;
            this.trip = trip;
            this.vision_zone = vision_zone;
            this.contact_zone = contact_zone;
            this.gestation_period = gestation_period;
            this.alimentation = alimentation;
        }

        public void Nivenergy() //méthode permettant de diminuer le niveau d'énergie des animaux
        {

            if (Energy_point == 0) //si le niveau d'énergie atteint 0 c'est la santé qui diminue
            {
                
                if (Health_point > 0)
                {
                    Console.WriteLine("Plus d'énergie, perte de santé: " + Health_point);
                    Health_point--;                                  
                }
                else if (Health_point == 0) //lorsque le niveau de santé atteint 0, l'animal se transforme en morceau de viande
                {
                    meat m = new meat(5, 5, OX, OY);
                    m.new_meat();
                    Health_point--;
                }
            }
            else
            {
                Energy_point--;
                Console.WriteLine("Niveau d'énergie à " + Energy_point);
            }
        }

        public void Movement() //méthode permettant de déplacer l'animal
        {
            Random rnd = new Random(); //l'animal va se déplacer de manière aléatoire dans un certains périmètre

            OX = rnd.Next((OX - trip), (OX + trip));

            OY = rnd.Next((OY - trip), (OY + trip));
            Console.WriteLine("je me déplace vers (" + OX + ", " + OY + ")");
        }

        public void Contact()
        {
            Carnivore cfemale = new Carnivore(Health_point, Energy_point, OX, OY, gender, trip, vision_zone, contact_zone, gestation_period, alimentation);
            Herbivore hmale = new Herbivore(Health_point, Energy_point, OX, OY, gender, trip, vision_zone, contact_zone, gestation_period, alimentation);
            Herbivore hmale1 = new Herbivore(Globals.Health_point2, 4, -2, -3, "male", 4, 6, 2, 0, "herbivore");
            //Carnivore cmale1 = new Carnivore(5, 10, -3, -6, "female", 4, 6, 2, 0, "carnivore");

            int OX2 = hmale1.OX;
            int OY2 = hmale1.OY;
            string gender2 = hmale1.gender;
            string alimentation2 = hmale1.alimentation;

            if (Math.Abs(OX - OX2) <= vision_zone && Math.Abs(OY - OY2) <= vision_zone) //si une autre entitée est dans son champs de vision
            {
                Console.WriteLine("Quelqu'un en vue");

                if (Math.Abs(OX - OX2) <= contact_zone && Math.Abs(OY - OY2) <= contact_zone) //si l'entitée est en contact
                {
                    Console.WriteLine("Je suis en contact avec quelqu'un");
                    if (alimentation2 == alimentation) //si je suis de la même espèce
                    {
                        Console.WriteLine("individu de la même espèce");
                        if (gender2 != gender && gestation_period == 0) //si les 2 animaux sont de sexe opposé et ne se sont pas encore accouplé, se reproduisent
                        {
                            Console.WriteLine("individu du sexe opposé, je me reproduis");
                            gestation_period = gestation_period + 1;
                        }
                        else
                        {
                            Console.WriteLine("individu du même sexe, je ne me reproduis pas, je suis pas gay!"); //ne fait rien car même sexe et même espèce
                        }
                    }
                    else if (alimentation == "carnivore" && Globals.Health_point2 > 0) //si un carnivore rencontre un herbivore
                    {
                        Console.WriteLine("J'attaque ma proie");
                        cfemale.attack_animal();
                        Globals.Health_point2 = 0;
                        
                    }
                    else if (alimentation == "herbivore") //si un herbivore rencontre un carnivore
                    {
                        Console.WriteLine("je suis attaqué");
                    }
                }
                else
                {
                    Console.WriteLine("Je me rapproche de ma cible en ("+OX2+", "+OY2+")"); //si la cible est vue mais est trop loin
                    OX = OX2;
                    OY = OY2;
                }
            }
            else
            {
                Console.WriteLine("Personne en vue");
                cfemale.Movement();
            }
            
            if (alimentation == "carnivore")
            {
                cfemale.eat_meat();
                Energy_point = cfemale.Energy_point;
            }
            else 
            {
                hmale.eat_plant();
                Energy_point = hmale.Energy_point;
            }

        }
        public void déféquer() //méthode permettant de laisser des déchets organiques
        {
            Random rnd = new Random();

            int Proba = rnd.Next(1, 10); //il y a une chance sur 10 qu'un déchet organique soit crée

            if (Proba == 1)
            {
                organic_waste w = new organic_waste(OX, OY);
                Console.WriteLine("J'ai fait caca, Poop");               
            }               
        }

        public void gestation() //méthode permettant de gérer la période de gestation
        {
            Animal a = new Animal(Health_point, Energy_point, OX, OY, gender, trip, vision_zone, contact_zone, gestation_period, alimentation);

            if (gestation_period == 9 && a.gender =="female")
            {
                gestation_period = gestation_period + 1;
                Console.WriteLine("Nouveau-né");
            }
            else if (gestation_period > 0 && a.gender == "female")
            {
                gestation_period = gestation_period + 1;
            }
            else if (gestation_period > 9)
            {
                gestation_period = 0;
            }
        }


    }
}
