﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class Carnivore : Animal
    {
        public Carnivore(int Health_point, int Energy_point, int OX, int OY, string gender, int trip, int vision_zone, int contact_zone, int gestation_period, string alimentation) : base(Health_point, Energy_point, OX, OY, gender, trip, vision_zone, contact_zone, gestation_period, alimentation)
        {

        }
        public void attack_animal() //méthode qui transforme l'herbivore en morceau de viande pour être mangé
        {
            meat m = new meat(5, 1, OX, OY);
            int food_value = m.food_value;

            Energy_point = Energy_point + food_value;
            Console.WriteLine("J'ai récupéré de l'énergie, je suis à " + Energy_point);
        }
        public void eat_meat() //méthode permettant aux carnivores de  de manger les morceaux de viandes se trouvant près de lui
        {
            meat m = new meat(5, 1, 1, 1);
            int OX2 = m.OX;
            int OY2 = m.OY;

            if (Energy_point<5)
            {
                if (Math.Abs(OX - OX2) <= vision_zone && Math.Abs(OY - OY2) <= vision_zone)
                {
                    Console.WriteLine("Morceau de viande en vue");

                    if (Math.Abs(OX - OX2) <= contact_zone && Math.Abs(OY - OY2) <= contact_zone)
                    {
                        Energy_point = Energy_point + m.food_value;
                        m.food_value = 0;
                        Console.WriteLine("Je mange un morceau de viande");
                    }
                }
                else
                {
                    OX = OX2;
                    OY = OY2;
                }
            }
            else
            {

            }
        }
    }
}
