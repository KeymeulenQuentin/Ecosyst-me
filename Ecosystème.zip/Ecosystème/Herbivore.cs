﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class Herbivore : Animal
    {
        public Herbivore(int Health_point, int Energy_point, int OX, int OY, string gender, int trip, int vision_zone, int contact_zone, int gestation_period, string alimentation) : base(Health_point, Energy_point, OX, OY, gender, trip, vision_zone, contact_zone, gestation_period, alimentation)
        {

        }
        public void eat_plant() //méthode permettant à l'herbivore de manger les plantes qui se trouvent près de lui
        {
            Plant p = new Plant(5, 5, 1, 2, 2, 2);
            int OX2 = p.OX;
            int OY2 = p.OY;

            if (Math.Abs(OX - OX2) <= vision_zone && Math.Abs(OY - OY2) <= vision_zone)
            {
                Console.WriteLine("Une plante en vue");

                if (Math.Abs(OX - OX2) <= contact_zone && Math.Abs(OY - OY2) <= contact_zone)
                {
                    p = null;
                    Energy_point = Energy_point + 4;
                    Console.WriteLine("Je mange une plante");
                }
            }
            else
            {
                OX = OX2;
                OY = OY2;
            }
        }
    }
}
