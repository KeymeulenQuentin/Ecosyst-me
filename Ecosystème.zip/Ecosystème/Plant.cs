﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class Plant : Specie
    {
        public int Health_point;
        public int Energy_point;
        public int root_zone;
        public int sowing_zone;

        public Plant(int Health_point, int Energy_point, int OX, int OY, int root_zone, int sowing_zone) : base(OX, OY)
        {
            this.Health_point = Health_point;
            this.Energy_point = Energy_point;
            this.root_zone = root_zone;
            this.sowing_zone = sowing_zone;
        }
        public void nivenergy_plant() //méthode gérant le niveau de vie et d'énergie de la plante
        {
            if (Energy_point == 0)
            {
                Health_point--;
                Console.WriteLine("La plante perd de la santé, niveau de santé à "+Health_point);
                if (Health_point == 0)
                {
                    organic_waste w = new organic_waste(OX, OY);
                    w.new_organic_waste();
                }
            }
            else
            {
                Energy_point--;
                Console.WriteLine("La plante pert de l'énergie, niveau d'énergie à "+Energy_point);
            }

        }

        public void feed_plant() //méthode permettant à la plante de se nourrir de déchets organique
        {
            organic_waste w = new organic_waste(OX, OY);
            int OX2 = w.OX;
            int OY2 = w.OY;

            if (Math.Abs(OX - OX2) <= root_zone && Math.Abs(OY - OY2) <= root_zone)
            {
                Console.WriteLine("La plante se nourris de déchet organique");
                Energy_point += 3;
            }
            else
            {

            }
        }
        public void multiply_plant() //méthode créant des plantes aux alentours d'une plante
        {
            Random rnd = new Random();

            int Proba = rnd.Next(1, 5);

            if (Proba == 1) 
            {
                int newOX = rnd.Next(OX - sowing_zone, OX + sowing_zone);
                int newOY = rnd.Next(OY - sowing_zone, OY + sowing_zone);

                Plant NouvellePlante = new Plant(5, 5, newOX, newOY, 2, 2);
                Console.WriteLine("Une nouvelle plante a été crée en (" + newOX +", " + newOY +")");

            }
        }
    }
}
