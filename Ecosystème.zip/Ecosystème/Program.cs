﻿using System;

namespace Ecosystème
{
    public class Program
    {
        static void Main(string[] args)
        {
            Plant p = new Plant(5, 5, 1, 2, 2 ,2);
            Animal cfemale = new Animal(5, 10, 0, 0, "female", 5, 5, 2, 0, "carnivore");
            Animal hmale = new Animal(5, 10, 9, 9, "male", 5, 5, 2, 0, "herbivore");
            meat m = new meat(5, 7, 1, 1);
            int number = 0;

            Console.WriteLine("---Début de la simulation---");

            while (number < 20)
            {
                Console.WriteLine(" ");
                Console.WriteLine("--boucle " + number + "--");
                Console.WriteLine(" ");

                Console.WriteLine("-Action du carnivore:");
                cfemale.Nivenergy();
                cfemale.Contact();
                cfemale.Movement();
                cfemale.déféquer();
                cfemale.gestation();
                

                Console.WriteLine(" ");
                Console.WriteLine("-Action de l'herbivore:");
                hmale.Nivenergy();
                hmale.Contact();
                hmale.Movement();
                hmale.déféquer();
                

                Console.WriteLine(" ");

                m.decomp();

                p.nivenergy_plant();
                p.feed_plant();
                p.multiply_plant();

                Console.WriteLine("________________________________________________");

                number++;
            }
            Console.WriteLine(" ");
            Console.WriteLine("Fin de la simulation");
        }

    }
 }