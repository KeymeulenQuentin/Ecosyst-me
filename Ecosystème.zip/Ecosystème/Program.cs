﻿using System;

namespace Ecosystème
{
    public class Program
    {
        static void Main(string[] args)
        {
            Plant p = new Plant(5, 5, 1, 2, 2 ,2);
            Animal cfemale = new Animal(10, 10, 0, 0, "male", 4, 6, 2, 0, "carnivore");
            Animal hmale = new Animal(7, 10, -4, -6, "female", 4, 6, 2, 0, "herbivore");
            meat m = new meat(5, 7, 1, 1);
            int number = 0;

            Console.WriteLine("---Début de la simulation---");

            while (number < 25)
            {
                Console.WriteLine(" ");
                Console.WriteLine("--boucle " + number + "--");
                Console.WriteLine(" ");

                if (cfemale.Health_point > 0)
                {

                    Console.WriteLine("-Action du carnivore:");
                    cfemale.Nivenergy();
                    cfemale.Contact();
                    cfemale.Movement();
                    cfemale.déféquer();
                    cfemale.gestation();

                }

                if (hmale.Health_point > 0)
                {
                    Console.WriteLine(" ");
                    Console.WriteLine("-Action de l'herbivore:");
                    hmale.Nivenergy();
                    hmale.Contact();
                    hmale.Movement();
                    hmale.déféquer();
                    hmale.gestation();
                }

                Console.WriteLine(" ");

                m.decomp();
                p.nivenergy_plant();
                p.feed_plant();
                p.multiply_plant();

                Console.WriteLine("_____________________________________________________");

                number++;
            }
            Console.WriteLine(" ");
            Console.WriteLine("Fin de la simulation");
        }

    }
 }