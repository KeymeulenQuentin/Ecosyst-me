﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class meat
    {
        public int food_value;
        public int decomposing;
        public int OX;
        public int OY;
        public meat(int food_value, int decomposing, int OX, int OY)
        {
            this.food_value = food_value;
            this.decomposing = decomposing;
            this.OX = OX;
            this.OY = OY;
        }
        public void new_meat()
        {
            Console.WriteLine("Individu mort, création d'un morceau de viande en ("+ OX+", "+OY+")");
        }
        public void decomp() //méthode qui va décrémenté la valeur de décomposition de la viande jusque 0 et la transformé en déchet organique si elle n'est pas mangé
        {
            if (decomposing == 0)
            {
                organic_waste w = new organic_waste(OX, OY);
                w.new_organic_waste();
                Console.WriteLine("Un morceau de viande est devenu un déchet organique");
                decomposing--;
            }
            else
            {
                decomposing--;

            }
        }
    }
}
