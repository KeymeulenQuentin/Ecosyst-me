﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class organic_waste
    {
        public int OX;
        public int OY;
        public organic_waste(int OX, int OY)
        {
            this.OX = OX;
            this.OY = OY;
        }
        public void new_organic_waste()
        {
            Console.WriteLine("Un nouveau déchet organique a été créé");
        }
    }
}
