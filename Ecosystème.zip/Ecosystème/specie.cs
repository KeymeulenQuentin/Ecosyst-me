﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecosystème
{
    public class Specie : Program
    {
        public int OX;
        public int OY;

        public Specie(int OX, int OY)
        {
            this.OX = OX;
            this.OY = OY;

        }
    }
}
